# BorrowBuddy v2

Full-stack foundation for BorrowBuddy using Node.js, Express, PostgreSQL, Prisma, JWT, bcrypt, and a static HTML/CSS/JS frontend.

## Step 1 setup

1. Install Node.js 20+ and PostgreSQL.
2. Open a terminal in `backend`.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your PostgreSQL connection string in `DATABASE_URL`.
6. Run `npx prisma generate`.
7. Run `npx prisma migrate dev --name init`.
8. Run `npm run seed`.
9. Run `npm run dev`.
10. Open `http://localhost:5000`.

Seed admin:
- Email: admin@borrowbuddy.com
- Password: admin123

Change the seed password before deployment.

The frontend is served by Express from `frontend/`.
