const API = {
  token: localStorage.getItem("bb_token"),

  async request(url, options = {}) {
    const headers = { ...(options.body ? {"Content-Type":"application/json"} : {}), ...(options.headers || {}) };
    if (this.token) headers.Authorization = `Bearer ${this.token}`;

    const response = await fetch(url, { ...options, headers, credentials: "include" });
    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      const error = new Error(data.error || "Request failed.");
      error.status = response.status;
      throw error;
    }
    return data;
  },

  get(url) {
    return this.request(url);
  },

  post(url, body) {
    return this.request(url, { method: "POST", body: JSON.stringify(body) });
  },

  patch(url, body) {
    return this.request(url, { method: "PATCH", body: JSON.stringify(body) });
  },

  put(url, body) {
    return this.request(url, { method: "PUT", body: JSON.stringify(body) });
  },

  delete(url) {
    return this.request(url, { method: "DELETE" });
  },

  async login(email, password) {
    const data = await this.post("/api/auth/login", { email, password });
    this.token = data.token;
    localStorage.setItem("bb_token", data.token);
    return data;
  },

  async signup(name, email, password) {
    const data = await this.post("/api/auth/signup", { name, email, password });
    this.token = data.token;
    localStorage.setItem("bb_token", data.token);
    return data;
  },

  logout() {
    this.token = null;
    localStorage.removeItem("bb_token");
    location.href = "/";
  }
};
