import "dotenv/config";
import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const adminEmail = "admin@borrowbuddy.com";

const existing = await prisma.user.findUnique({ where: { email: adminEmail } });

if (!existing) {
  await prisma.user.create({
    data: {
      name: "Admin",
      email: adminEmail,
      passwordHash: await bcrypt.hash("admin123", 12),
      role: "ADMIN"
    }
  });
  console.log("Admin created.");
} else {
  console.log("Admin already exists.");
}

await prisma.$disconnect();
