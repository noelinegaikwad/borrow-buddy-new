import { Router } from "express";
import { prisma } from "../config/prisma.js";
import { requireAuth } from "../middleware/auth.js";
import { requireAdmin } from "../middleware/admin.js";

const router = Router();
router.use(requireAuth, requireAdmin);

router.get("/stats", async (_req, res) => {
  const [users, items, requests] = await Promise.all([
    prisma.user.count(),
    prisma.item.count(),
    prisma.borrowRequest.count()
  ]);
  res.json({ users, items, requests });
});

router.get("/users", async (_req, res) => {
  const users = await prisma.user.findMany({
    select: { id: true, name: true, email: true, role: true, joined: true, rating: true },
    orderBy: { joined: "desc" }
  });
  res.json({ users });
});

router.delete("/users/:id", async (req, res) => {
  if (req.params.id === req.user.userId) return res.status(400).json({ error: "You cannot delete yourself." });
  await prisma.user.delete({ where: { id: req.params.id } });
  res.json({ ok: true });
});

export default router;
