import { Router } from "express";
import { prisma } from "../config/prisma.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const { search, category, location, available } = req.query;
    const items = await prisma.item.findMany({
      where: {
        ...(search ? { OR: [
          { name: { contains: search, mode: "insensitive" } },
          { description: { contains: search, mode: "insensitive" } }
        ] } : {}),
        ...(category ? { category } : {}),
        ...(location ? { location: { contains: location, mode: "insensitive" } } : {}),
        ...(available === "true" ? { available: true } : {})
      },
      include: { owner: { select: { id: true, name: true, rating: true } } },
      orderBy: { createdAt: "desc" }
    });
    res.json({ items });
  } catch {
    res.status(500).json({ error: "Unable to load items." });
  }
});

router.get("/:id", async (req, res) => {
  const item = await prisma.item.findUnique({
    where: { id: req.params.id },
    include: { owner: { select: { id: true, name: true, rating: true, reviewCount: true } } }
  });
  if (!item) return res.status(404).json({ error: "Item not found." });
  res.json({ item });
});

router.post("/", requireAuth, async (req, res) => {
  try {
    const { name, category, condition, description, location, imageUrl, priceType, priceAmount } = req.body;
    if (!name || !category || !condition || !description || !location) {
      return res.status(400).json({ error: "Please complete all required fields." });
    }

    const item = await prisma.item.create({
      data: {
        name, category, condition, description, location,
        imageUrl: imageUrl || null,
        priceType: priceType === "paid" ? "PAID" : "FREE",
        priceAmount: priceType === "paid" ? Number(priceAmount || 0) : 0,
        ownerId: req.user.userId
      }
    });
    res.status(201).json({ item });
  } catch {
    res.status(500).json({ error: "Unable to create item." });
  }
});

router.put("/:id", requireAuth, async (req, res) => {
  const item = await prisma.item.findUnique({ where: { id: req.params.id } });
  if (!item) return res.status(404).json({ error: "Item not found." });
  if (item.ownerId !== req.user.userId && req.user.role !== "ADMIN") {
    return res.status(403).json({ error: "You cannot edit this item." });
  }

  const { name, category, condition, description, location, imageUrl, priceType, priceAmount } = req.body;
  const updated = await prisma.item.update({
    where: { id: item.id },
    data: {
      name, category, condition, description, location, imageUrl,
      priceType: priceType === "paid" ? "PAID" : "FREE",
      priceAmount: priceType === "paid" ? Number(priceAmount || 0) : 0
    }
  });
  res.json({ item: updated });
});

router.delete("/:id", requireAuth, async (req, res) => {
  const item = await prisma.item.findUnique({ where: { id: req.params.id } });
  if (!item) return res.status(404).json({ error: "Item not found." });
  if (item.ownerId !== req.user.userId && req.user.role !== "ADMIN") {
    return res.status(403).json({ error: "You cannot delete this item." });
  }
  await prisma.item.delete({ where: { id: item.id } });
  res.json({ ok: true });
});

export default router;
