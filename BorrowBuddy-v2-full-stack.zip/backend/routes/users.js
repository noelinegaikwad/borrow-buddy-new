import { Router } from "express";
import { prisma } from "../config/prisma.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

router.get("/:id", async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.params.id },
    select: {
      id: true, name: true, bio: true, imageUrl: true, rating: true,
      reviewCount: true, joined: true,
      items: { where: { available: true }, orderBy: { createdAt: "desc" } }
    }
  });
  if (!user) return res.status(404).json({ error: "User not found." });
  res.json({ user });
});

router.put("/me", requireAuth, async (req, res) => {
  const { name, bio, imageUrl } = req.body;
  const user = await prisma.user.update({
    where: { id: req.user.userId },
    data: { name: name?.trim(), bio, imageUrl }
  });
  const { passwordHash, ...safe } = user;
  res.json({ user: safe });
});

export default router;
