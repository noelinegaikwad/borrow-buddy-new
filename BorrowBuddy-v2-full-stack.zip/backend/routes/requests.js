import { Router } from "express";
import { prisma } from "../config/prisma.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

router.get("/mine", requireAuth, async (req, res) => {
  const requests = await prisma.borrowRequest.findMany({
    where: { borrowerId: req.user.userId },
    include: { item: { include: { owner: { select: { id: true, name: true } } } } },
    orderBy: { createdAt: "desc" }
  });
  res.json({ requests });
});

router.get("/incoming", requireAuth, async (req, res) => {
  const requests = await prisma.borrowRequest.findMany({
    where: { item: { ownerId: req.user.userId } },
    include: { item: true, borrower: { select: { id: true, name: true, email: true } } },
    orderBy: { createdAt: "desc" }
  });
  res.json({ requests });
});

router.post("/", requireAuth, async (req, res) => {
  const { itemId } = req.body;
  const item = await prisma.item.findUnique({ where: { id: itemId } });

  if (!item) return res.status(404).json({ error: "Item not found." });
  if (item.ownerId === req.user.userId) return res.status(400).json({ error: "You cannot borrow your own item." });
  if (!item.available) return res.status(400).json({ error: "This item is currently unavailable." });

  const existing = await prisma.borrowRequest.findFirst({
    where: { itemId, borrowerId: req.user.userId, status: "PENDING" }
  });
  if (existing) return res.status(409).json({ error: "You already have a pending request for this item." });

  const request = await prisma.borrowRequest.create({
    data: { itemId, borrowerId: req.user.userId }
  });
  res.status(201).json({ request });
});

router.patch("/:id/status", requireAuth, async (req, res) => {
  const { status } = req.body;
  const allowed = ["ACCEPTED", "REJECTED", "RETURNED"];
  if (!allowed.includes(status)) return res.status(400).json({ error: "Invalid status." });

  const request = await prisma.borrowRequest.findUnique({
    where: { id: req.params.id },
    include: { item: true }
  });
  if (!request) return res.status(404).json({ error: "Request not found." });

  const isOwner = request.item.ownerId === req.user.userId;
  const isBorrower = request.borrowerId === req.user.userId;

  if ((status === "ACCEPTED" || status === "REJECTED") && !isOwner) {
    return res.status(403).json({ error: "Only the item owner can accept or reject a request." });
  }
  if (status === "RETURNED" && !isBorrower) {
    return res.status(403).json({ error: "Only the borrower can mark an item returned." });
  }

  const updated = await prisma.$transaction(async tx => {
    const r = await tx.borrowRequest.update({
      where: { id: request.id },
      data: { status }
    });

    if (status === "ACCEPTED") {
      await tx.item.update({ where: { id: request.itemId }, data: { available: false } });
      await tx.borrowRequest.updateMany({
        where: { itemId: request.itemId, id: { not: request.id }, status: "PENDING" },
        data: { status: "REJECTED" }
      });
    }

    if (status === "RETURNED" || status === "REJECTED") {
      await tx.item.update({ where: { id: request.itemId }, data: { available: true } });
    }

    return r;
  });

  res.json({ request: updated });
});

export default router;
